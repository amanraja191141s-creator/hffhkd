# SA Calculator v98.82 — CI failure micro-audit and fix report

## Failure reproduced from the supplied Actions log

The failed step was **Verify source files, release identity and test entry points**. It checked the service-worker source with a stale v98.81 condition:

```js
if(!sw.includes('v9881')) throw new Error('Service worker cache namespace does not match v98.81');
```

The release source itself is v98.82 and its authoritative cache namespace is:

```js
const CACHE='sa-calculator-v98-82-gst-keypad-audit-v9882';
```

Therefore the CI verifier rejected the correct v98.82 source. This is a workflow/release-identity mismatch, not a GST calculation or application runtime failure.

## Exact correction applied

- Replaced the loose/stale `v9881` check with an exact parsed `const CACHE` comparison against `sa-calculator-v98-82-gst-keypad-audit-v9882`.
- The diagnostic now reports the expected and actual cache values, including a clear `missing` case.
- Updated the source-selection step label and regression-suite step label from v98.81 to v98.82.
- Synchronized `.github/workflows/main.yml`, `Android-Workflow-v98.82.yml`, and the retained `Android-Workflow-v98.81.yml` compatibility copy byte-for-byte.
- Updated `tests/ci-cache-workflow.test.mjs` so this stale-cache regression is explicitly caught.
- Preserved the actual package version `1.98.96-v98.82` and Android `versionCode` `1099102`; no unnecessary app version bump was made for a CI-only correction.

## Verification results

- `npm test`: **99/99 passed**.
- Android web preparation: passed; 13 required assets verified.
- JavaScript syntax: all 7 workflow-checked source/script files passed `node --check`.
- YAML parse: 3/3 workflow copies parsed successfully.
- Workflow copies: byte-identical.
- Release identity: package, runtime, HTML, PWA manifest, service worker and workflow aligned to v98.82.
- Test entry points: all 17 files referenced by `test:release` exist; all 10 test paths explicitly required by the workflow exist and are included in `test:release`.
- Root and generated `www/` canonical assets: byte-identical.

## Remaining external verification

The supplied GitHub Actions run is already a completed historical run and cannot be changed by editing this local archive. To verify GitHub-hosted CI, commit the corrected `.github/workflows/main.yml` and matching v98.82 source files to the repository, then start a **new** workflow run. This report does not claim that the remote run has already passed.

No physical Android device test or APK build is claimed here.
